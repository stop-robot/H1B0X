// prevent clickjacking attack
if ( top !== self ) {
	top.location = self.location
} else {
document.write ('  <table width="937" border="0" align="center" cellpadding="0" cellspacing="0">\n');
document.write ('    <tr>\n');
document.write ('      <td height="25" align="right" valign="top" background="uwc/images_tw/header_01.jpg">\n');
document.write ('    	<table width="370" border="0" cellpadding="0" cellspacing="0">\n');
document.write ('        <tr>\n');
document.write ('          <td width="158" height="24" align="right" valign="middle">\n');
document.write ('    		<img src="https://hibox.hinet.net/uwc/uwc/images_tw/icon-02.gif" width="18" height="15" align="middle" /> \n');
document.write ('  	    	<a href="https://apply.hibox.hinet.net/hiBox_extend/mailAdmin/login.php" target="_blank" class="manage">管理者登入\n');
document.write ('  	  	  </a> \n');
document.write ('		  <img src="https://hibox.hinet.net/uwc/uwc/images_tw/dis-02.gif" width="9" height="9" /> \n');
document.write ('   <a href="/uwc/uwc/homepage_tw/sitemap.html" class="manage"> 網站地圖\n');
document.write ('	  	  </a> \n');
document.write ('		  </td>\n');
document.write ('           <td width="195" align="center" valign="middle">\n');
document.write ('		  <a href="./index_zh-tw.html?lang=zh-tw" class="language">繁中\n');
document.write ('	    	</a> \n');
document.write ('		  <img src="https://hibox.hinet.net/uwc/uwc/images_tw/dis-02.gif" alt="" width="9" height="9" /> \n');
document.write ('		  <a href="./index_zh-cn.html?lang=zh-cn" class="language">簡中\n');
document.write ('		  </a> \n');
document.write ('		  <img src="https://hibox.hinet.net/uwc/uwc/images_tw/dis-02.gif" alt="" width="9" height="9" /> \n');
document.write ('	    	<a href="./index_en.html?lang=en" class="language">English \n');
document.write ('	    	</a>\n');
document.write ('		    </td>\n');
document.write ('          <td width="17">&nbsp;\n');
document.write ('	  	  </td>\n');
document.write ('        </tr>\n');
document.write ('      </table>\n');
document.write ('	  </td>\n');
document.write ('    </tr>\n');
document.write ('  </table>\n');
document.write ('  <table width="937" border="0" align="center" cellpadding="0" cellspacing="0">\n');
document.write ('    <tr>\n');
document.write ('      <td height="81"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/header_02.jpg" width="937" height="81" border="0" usemap="#Map" />\n');
document.write ('	  </td>\n');
document.write ('    </tr>\n');
document.write ('  </table>\n');
document.write ('  <map name="Map" id="Map">\n');
document.write ('    <area shape="rect" coords="32,2,267,54" href="./index_zh-tw.html?lang=zh-tw" alt="回首頁" />\n');
document.write ('    <area shape="rect" coords="723,39,882,62" href="https://hib2border.hinet.net/HiB2B/alf/hiB2BTrModify.jsp?funCode=401" target="_blank" alt="立即申請試用TRY IT!" />\n');
document.write ('  </map>\n');
document.write ('  <table width="937" border="0" align="center" cellpadding="0" cellspacing="0">\n');
document.write ('  <tr>\n');
document.write ('  <td width="71" valign="top"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/GlobalNavigation01_01.gif" width="71" height="31" /></td>\n');
document.write ('  <td width="808"><ul class="menu">\n');
document.write ('   <li class="top p1"><a href="./index_zh-tw.html?lang=zh-tw" id="home" class="top_link" alt="回首頁"><span>Home</span></a></li>\n');
document.write ('   <li class="top p2"><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/features.html" id="products" class="top_link" alt="產品簡介"><span>products</span><!--[if IE 7]><!--></a><!--<![endif]-->\n');
document.write ('    <!--[if lte IE 6]><table><tr><td><![endif]-->\n');
document.write ('    <ul class="sub">\n');
document.write ('     <li><a href="uwc/homepage_tw/features.html">產品特色</a></li>\n');
document.write ('     <li><a href="uwc/homepage_tw/functions.html">功能說明</a></li>\n');
document.write ('     <li><a href="uwc/homepage_tw/advantages.html">服務優勢</a></li>\n');
document.write ('     <li><a href="uwc/homepage_tw/benefits.html">使用效益</a></li>\n');
document.write ('     <li><a href="#" class="fly">加值服務<!--[if IE 7]><!--></a><!--<![endif]-->\n'); 
document.write ('       <!--[if lte IE 6]><table><tr><td><![endif]-->\n');
document.write ('       <ul>\n');
document.write ('        <li><a href="uwc/homepage_tw/audit.html">郵件稽核</a></li>\n');
document.write ('        <li><a href="uwc/homepage_tw/backup.html">郵件備份</a></li>\n');
document.write ('        <li><a href="uwc/homepage_tw/smsotp.html">簡訊OTP</a></li>\n');
/*document.write ('        <li><a href="/uwc/uwc/homepage_tw/vas.html">快遞郵</a></li>\n');*/
document.write ('       </ul>\n');
document.write ('       <!--[if lte IE 6]></td></tr></table></a><![endif]-->\n');
document.write ('    </ul>\n');
document.write ('    <!--[if lte IE 6]></td></tr></table></a><![endif]-->\n');
document.write ('   </li>\n');
document.write ('  <li class="top p3"><a href="/uwc/uwc/homepage_tw/promotion02.html" id="prices" class="top_link"><span>prices</span></a></li>\n');
/*
document.write ('  <li class="top p3"><a href="/uwc/uwc/homepage_tw/promotion02.html" id="prices" class="top_link"><span>prices</span><!--[if IE 7]><!--></a><!--<![endif]-->\n');
document.write ('    <!--[if lte IE 6]><table><tr><td><![endif]-->\n'); 
document.write ('    <ul class="sub">\n');
document.write ('     <li><a href="/uwc/uwc/homepage_tw/promotion.html">最新優惠</a></li>\n');
document.write ('     <li><a href="/uwc/uwc/homepage_tw/promotion02.html">產品費率</a></li>\n');
document.write ('    </ul>\n');
document.write ('    <!--[if lte IE 6]></td></tr></table></a><![endif]-->\n'); 
document.write ('   </li>\n');
*/
document.write ('  <li class="top p4"><a href="/uwc/uwc/homepage_tw/case.html" id="scases" class="top_link"><span>scases</span></a></li>\n');
document.write ('   <li class="top p5"><a href="/uwc/uwc/homepage_tw/docs.html" id="downloads" class="top_link"><span>downloads</span><!--[if IE 7]><!--></a><!--<![endif]-->\n');
document.write ('    <!--[if lte IE 6]><table><tr><td><![endif]-->\n');

document.write ('    <ul class="sub">\n');
document.write ('     <li><a href="uwc/homepage_tw/docs.html">產品文件</a></li>\n');
document.write ('     <li><a href="uwc/homepage_tw/manuals.html">使用手冊</a></li>\n');
document.write ('    </ul>\n');
document.write ('    <!--[if lte IE 6]></td></tr></table></a><![endif]-->\n');
document.write ('   </li>\n');
document.write ('   <li class="top p6"><a href="/uwc/uwc/homepage_tw/apply.html" id="applications" class="top_link"><span>applications</span></a></li>\n');
document.write ('   <li class="top p7"><a href="/uwc/uwc/homepage_tw/bizs.html" id="faq" class="top_link"><span>faq</span><!--[if IE 7]><!--></a><!--<![endif]-->\n');
document.write ('    <!--[if lte IE 6]><table><tr><td><![endif]-->\n');

document.write ('    <ul class="sub">\n');
document.write ('     <li><a href="uwc/homepage_tw/bizs.html">業務申請</a></li>\n');
document.write ('     <li><a href="uwc/homepage_tw/tech.html">技術支援</a></li>\n');
document.write ('    </ul>\n');
document.write ('    <!--[if lte IE 6]></td></tr></table></a><![endif]-->\n');
document.write ('   </li>\n');
document.write ('   <li class="top p8"><a href="/uwc/uwc/homepage_tw/contact.html" id="contactus" class="top_link"><span>contactus</span></a></li>\n');
document.write ('  </ul>\n');
document.write ('    <div class="box250"></div></td>\n');
document.write ('  <td width="58" valign="top"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/GlobalNavigation01_10.gif" width="58" height="31" /></td>\n');
document.write ('  </tr>\n');
document.write ('  </table>\n');

}
