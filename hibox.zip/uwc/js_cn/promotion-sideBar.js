document.write ('<table width="100" border="0" cellpadding="0" cellspacing="0">\n');
document.write ('      <tr>\n');
document.write ('        <td><img src="/uwc/uwc/images_cn/Pricing_02.jpg" width="177" height="171" /></td>\n');
document.write ('      </tr>\n');
document.write ('    </table>\n');
document.write ('      <table width="177" border="0" cellpadding="0" cellspacing="0">\n');
document.write ('        <tr>\n');
document.write ('          <td><img src="/uwc/uwc/images_cn/inTheme_07.gif" width="177" height="1" /></td>\n');
document.write ('        </tr>\n');
/*
//document.write ('        <tr>\n');
//document.write ('          <td height="28">　<a href="promotion.html" class="product">最新优惠</a></td>\n');
//document.write ('        </tr>\n');
//document.write ('        <tr>\n');
//document.write ('          <td><img src="/uwc/uwc/images_cn/inTheme_07.gif" width="177" height="1" /></td>\n');
//document.write ('        </tr>\n');
document.write ('        <tr>\n');
document.write ('          <td height="28">　<a href="promotion02.html" class="product">产品费率</a></td>\n');
document.write ('        </tr>\n');
document.write ('        <tr>\n');
document.write ('          <td><img src="/uwc/uwc/images_cn/inTheme_07.gif" width="177" height="1" /></td>\n');
*/
document.write ('      </table>\n');
