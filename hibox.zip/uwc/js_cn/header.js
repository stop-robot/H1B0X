// prevent clickjacking attack
if ( top !== self ) {
        top.location = self.location
} else {
document.write ('  <table width="937" border="0" align="center" cellpadding="0" cellspacing="0">\n');
document.write ('    <tr>\n');
document.write ('      <td height="25" align="right" valign="top" background="uwc/images_cn/header_01.jpg">\n');
document.write ('    	<table width="370" border="0" cellpadding="0" cellspacing="0">\n');
document.write ('        <tr>\n');
document.write ('          <td width="158" height="24" align="right" valign="middle">\n');
document.write ('    		<img src="https://hibox.hinet.net/uwc/uwc/images_cn/icon-02.gif" width="18" height="15" align="middle" /> \n');
document.write ('  	    	<a href="https://apply.hibox.hinet.net/hiBox_extend/mailAdmin/login.php" target="_blank" class="manage">管理者登入\n');
document.write ('  	  	  </a> \n');
document.write ('		  <img src="https://hibox.hinet.net/uwc/uwc/images_cn/dis-02.gif" width="9" height="9" /> \n');
document.write ('   <a href="/uwc/uwc/homepage_cn/sitemap.html" class="manage"> 网站地图\n');
document.write ('	  	  </a> \n');
document.write ('		  </td>\n');
document.write ('           <td width="195" align="center" valign="middle">\n');
document.write ('		  <a href="./index_zh-tw.html?lang=zh-tw" class="language">繁中\n');
document.write ('	    	</a> \n');
document.write ('		  <img src="https://hibox.hinet.net/uwc/uwc/images_cn/dis-02.gif" alt="" width="9" height="9" /> \n');
document.write ('		  <a href="./index_zh-cn.html?lang=zh-cn" class="language">简中\n');
document.write ('		  </a> \n');
document.write ('		  <img src="https://hibox.hinet.net/uwc/uwc/images_cn/dis-02.gif" alt="" width="9" height="9" /> \n');
document.write ('	    	<a href="./index_en.html?lang=en" class="language">English \n');
document.write ('	    	</a>\n');
document.write ('		    </td>\n');
document.write ('          <td width="17">&nbsp;\n');
document.write ('	  	  </td>\n');
document.write ('        </tr>\n');
document.write ('      </table>\n');
document.write ('	  </td>\n');
document.write ('    </tr>\n');
document.write ('  </table>\n');
document.write ('  <table width="937" border="0" align="center" cellpadding="0" cellspacing="0">\n');
document.write ('    <tr>\n');
document.write ('      <td height="81"><img src="https://hibox.hinet.net/uwc/uwc/images_cn/header_02.jpg" width="937" height="81" border="0" usemap="#Map" />\n');
document.write ('	  </td>\n');
document.write ('    </tr>\n');
document.write ('  </table>\n');
document.write ('  <map name="Map" id="Map">\n');
document.write ('    <area shape="rect" coords="32,2,267,54" href="./index_zh-cn.html?lang=zh-cn" alt="回首页" />\n');
document.write ('    <area shape="rect" coords="723,39,882,62" href="https://hib2border.hinet.net/HiB2B/alf/hiB2BTrModify.jsp?funCode=401" target="_blank" alt="立即申请试用TRY IT!" />\n');
document.write ('  </map>\n');
document.write ('  <table width="937" border="0" align="center" cellpadding="0" cellspacing="0">\n');
document.write ('  <tr>\n');
document.write ('  <td width="71" valign="top"><img src="https://hibox.hinet.net/uwc/uwc/images_cn/GlobalNavigation01_01.gif" width="71" height="31" /></td>\n');
document.write ('  <td width="808"><ul class="menu">\n');
document.write ('   <li class="top p1"><a href="./index_zh-cn.html?lang=zh-cn" id="home" class="top_link" alt="回首页"><span>Home</span></a></li>\n');
document.write ('   <li class="top p2"><a href="/uwc/uwc/homepage_cn/features.html" id="products" class="top_link" alt="产品简介"><span>products</span><!--[if IE 7]><!--></a><!--<![endif]-->\n');
document.write ('    <!--[if lte IE 6]><table><tr><td><![endif]-->\n');
document.write ('    <ul class="sub">\n');
document.write ('     <li><a href="uwc/homepage_cn/features.html">产品特色</a></li>\n');
document.write ('     <li><a href="uwc/homepage_cn/functions.html">功能说明</a></li>\n');
document.write ('     <li><a href="uwc/homepage_cn/advantages.html">服务优势</a></li>\n');
document.write ('     <li><a href="uwc/homepage_cn/benefits.html">使用效益</a></li>\n');
document.write ('     <li><a href="#" class="fly">加值服务<!--[if IE 7]><!--></a><!--<![endif]-->\n'); 
document.write ('       <!--[if lte IE 6]><table><tr><td><![endif]-->\n');
document.write ('       <ul>\n');
document.write ('        <li><a href="uwc/homepage_cn/audit.html">邮件稽核</a></li>\n');
document.write ('        <li><a href="uwc/homepage_cn/backup.html">邮件备份</a></li>\n');
document.write ('        <li><a href="uwc/homepage_cn/smsotp.html">简讯OTP</a></li>\n');
/*
document.write ('        <li><a href="/uwc/uwc/homepage_cn/vas.html">快递邮</a></li>\n');
*/
document.write ('       </ul>\n');
document.write ('       <!--[if lte IE 6]></td></tr></table></a><![endif]-->\n');
document.write ('    </ul>\n');
document.write ('    <!--[if lte IE 6]></td></tr></table></a><![endif]-->\n');
document.write ('   </li>\n');
document.write ('  <li class="top p3"><a href="/uwc/uwc/homepage_cn/promotion02.html" id="prices" class="top_link"><span>prices</span></a></li>\n');
/*
document.write ('  <li class="top p3"><a href="#" id="prices" class="top_link"><span>prices</span><!--[if IE 7]><!--></a><!--<![endif]-->\n');
document.write ('    <!--[if lte IE 6]><table><tr><td><![endif]-->\n'); 
document.write ('    <ul class="sub">\n');
document.write ('     <li><a href="/uwc/uwc/homepage_cn/promotion.html">最新优惠</a></li>\n');
document.write ('     <li><a href="/uwc/uwc/homepage_cn/promotion02.html">产品费率</a></li>\n');
document.write ('    </ul>\n');
document.write ('    <!--[if lte IE 6]></td></tr></table></a><![endif]-->\n'); 
document.write ('   </li>\n');
*/
document.write ('  <li class="top p4"><a href="/uwc/uwc/homepage_cn/case.html" id="scases" class="top_link"><span>scases</span></a></li>\n');
document.write ('   <li class="top p5"><a href="/uwc/uwc/homepage_cn/docs.html" id="downloads" class="top_link"><span>downloads</span><!--[if IE 7]><!--></a><!--<![endif]-->\n');
document.write ('    <!--[if lte IE 6]><table><tr><td><![endif]-->\n');

document.write ('    <ul class="sub">\n');
document.write ('     <li><a href="uwc/homepage_cn/docs.html">产品文件</a></li>\n');
document.write ('     <li><a href="uwc/homepage_cn/manuals.html">使用手册</a></li>\n');
document.write ('    </ul>\n');
document.write ('    <!--[if lte IE 6]></td></tr></table></a><![endif]-->\n');
document.write ('   </li>\n');
document.write ('   <li class="top p6"><a href="/uwc/uwc/homepage_cn/apply.html" id="applications" class="top_link"><span>applications</span></a></li>\n');
document.write ('   <li class="top p7"><a href="/uwc/uwc/homepage_cn/bizs.html" id="faq" class="top_link"><span>faq</span><!--[if IE 7]><!--></a><!--<![endif]-->\n');
document.write ('    <!--[if lte IE 6]><table><tr><td><![endif]-->\n');

document.write ('    <ul class="sub">\n');
document.write ('     <li><a href="uwc/homepage_cn/bizs.html">业务申请</a></li>\n');
document.write ('     <li><a href="uwc/homepage_cn/tech.html">技术支持</a></li>\n');
document.write ('    </ul>\n');
document.write ('    <!--[if lte IE 6]></td></tr></table></a><![endif]-->\n');
document.write ('   </li>\n');
document.write ('   <li class="top p8"><a href="/uwc/uwc/homepage_cn/contact.html" id="contactus" class="top_link"><span>contactus</span></a></li>\n');
document.write ('  </ul>\n');
document.write ('    <div class="box250"></div></td>\n');
document.write ('  <td width="58" valign="top"><img src="https://hibox.hinet.net/uwc/uwc/images_cn/GlobalNavigation01_10.gif" width="58" height="31" /></td>\n');
document.write ('  </tr>\n');
document.write ('  </table>\n');
}
